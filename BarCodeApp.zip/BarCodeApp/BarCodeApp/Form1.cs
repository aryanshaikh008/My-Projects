﻿using System;
using System.IO;
using System.Windows.Forms;

namespace BarCodeApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            xGrid.Columns.Add("A", "Product-Name");
            xGrid.Columns.Add("B", "UnitPrice");
            xGrid.Columns.Add("C", "Qty");
            xGrid.Columns.Add("D", "Total");
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //Do nothing.
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Calculate_Bill()
        {
            int sum = 0;
            for (int i = 0; i < xGrid.Rows.Count-1; i++)
            {
                sum = sum + Int32.Parse(xGrid.Rows[i].Cells[3].Value.ToString());
            }
            lblTotal.Text = sum.ToString() + " Rs.";
        }

        private void txtCode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                StreamReader SR = new StreamReader("Products//" + txtCode.Text + ".txt");
                txtPName.Text = SR.ReadLine(); //Product-Name
                txtPPrice.Text = SR.ReadLine(); //Product-Price.
                txtQty.Text = SR.ReadLine(); //Quantity.
                SR.Close();
                txtQty.Focus();                
               
            }
        }

        private void txtQty_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                int T = Int32.Parse(txtPPrice.Text) * Int32.Parse(txtQty.Text);
                xGrid.Rows.Add(txtPName.Text, txtPPrice.Text, txtQty.Text, T.ToString());
                Calculate_Bill();
                txtCode.Clear();
                txtCode.Focus();                
            }
        }

        private void xGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = xGrid.CurrentRow.Index;
            xGrid.Rows.RemoveAt(i);
            Calculate_Bill();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            string DT = DateTime.Now.ToString("ddMMMyyyy-HHmmss");
            StreamWriter SW = new StreamWriter("Orders//"+DT+".txt");
            string A, B, C, D;
            for (int i = 0; i < xGrid.Rows.Count-1; i++)
            {
                A = xGrid.Rows[i].Cells[0].Value.ToString(); //Product-Name.
                B = xGrid.Rows[i].Cells[1].Value.ToString(); //Product-Price.
                C = xGrid.Rows[i].Cells[2].Value.ToString(); //Product-Quantity.
                D = xGrid.Rows[i].Cells[3].Value.ToString(); //Product-Total.
                SW.WriteLine(A+"#"+B+"#"+C+"#"+D);
            }            
            SW.Close();
            xGrid.Rows.Clear();
            lblTotal.Text = "0 Rs.";
            txtPName.Clear();
            txtPPrice.Clear();
        }
    }
}
