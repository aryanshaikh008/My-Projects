﻿using System;
using System.IO;
using System.Windows.Forms;

namespace BarCodeApp
{
    public partial class ViewOrders : Form
    {
        public ViewOrders()
        {
            InitializeComponent();
            xGrid.Columns.Add("A", "Product-Name");
            xGrid.Columns.Add("B", "UnitPrice");
            xGrid.Columns.Add("C", "Qty");
            xGrid.Columns.Add("D", "Total");
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            string[] Arr;
            StreamReader SR = new StreamReader("Orders//"+txtID.Text+".txt");
            while (!SR.EndOfStream)
            {
                Arr = SR.ReadLine().Split('#');
                xGrid.Rows.Add(Arr[0], Arr[1], Arr[2], Arr[3]);
            }
            SR.Close();
            Calculate_Bill();
        }
        private void Calculate_Bill()
        {
            int sum = 0;
            for (int i = 0; i < xGrid.Rows.Count - 1; i++)
            {
                sum = sum + Int32.Parse(xGrid.Rows[i].Cells[3].Value.ToString());
            }
            lblTotal.Text = sum.ToString() + " Rs.";
        }
       
    }
}
