﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyTaskManager
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            xGrid.Columns.Add("A","Process-ID");
            xGrid.Columns.Add("B","Process Name");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            xGrid.Rows.Clear();
            Process[] Arr = Process.GetProcesses();
            foreach (Process P in Arr)
            {
                xGrid.Rows.Add(P.Id , P.ProcessName);
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            Process.Start(txtApp.Text);
        }

        private void btnEnd_Click(object sender, EventArgs e)
        {
            int ID = Int32.Parse(txtApp.Text);
            Process P = Process.GetProcessById(ID);
            P.Kill();   
        }
    }
}
