Create Database RailwaymanagemenDB
use  RailwaymanagemenDB

drop table tblRegistration

Create table tblRegistration
 (

RID int identity(500,1) primary key,
PassengerName varchar(25),
PhoneNo varchar(25),
Railway varchar(50),
FromCity varchar(25),
ToCity varchar (25),
TravelDate varchar (25),
TicketPrice int,
NoSeats int,
Total int,
Status varchar(6)
);

select * from tblRegistration;
update tblRegistration set Status='True';

delete  from tblRegistration;

Insert into tblRegistration values('Mr. Ahmed Khan','0300-1234567','Shalimaar Express', 'Karachi', 'Lahore','10-NOV-2016','1200','3',3600,'True');
INSERT INTO tblRegistration VALUES('Mr. Kashif Ali','0333-1234567','Allama Iqbal Express', 'pindi', 'Karachi','12-NOV-2016','1500','5',7500,'True');
INSERT INTO tblRegistration VALUES('Mr. Tanveer','0345-1234567','Taez Gaam Express', 'Hyderabad', 'Multan','16-NOV-2016','800','4',3200,'True');
INSERT INTO tblRegistration VALUES('Mr. Iqbal Ahmed','0321-1234567','Night Coach Express', 'Tharparkar', 'Kot Addu','18-NOV-2016','500','2',1000,'True');
INSERT INTO tblRegistration VALUES('Mr. Ziauddin','0332-1234567','Shalimaar Express', 'Nawabshah', 'SialKot','20-NOV-2016','1300','1',1300,'True');
INSERT INTO tblRegistration VALUES('Mr. Zubair Ali','0334-1234567','Blue Line Express', 'Peshawer', 'Karachi','22-NOV-2016','2000','4',8000,'True');

-------------------

Create table tblFromCity

(
FromCityName varchar (20),

);
Insert into tblFromCity values ('karachi');
Insert into tblFromCity values ('Pindi'); 
Insert into tblFromCity values ('Hyderabad');	
Insert into tblFromCity values ('Tharparkar');	
Insert into tblFromCity values ('NawabSahah')	
Insert into tblFromCity values ('Peshawar')	
select * from tblFromCity;		

-------------------
Create table tblToCity
(
ToCityName varchar (20),

);
Insert into tblToCity values ('Lahore');
Insert into tblToCity values ('Karachi'); 
Insert into tblToCity values ('Mutan');	
Insert into tblToCity values ('Sialkot');	
Insert into tblToCity values ('Kot Addu')	
Insert into tblToCity values ('Islamabad')
select * from tblToCity;

---------------------------
Create table tblRailway
(
Railway varchar (20),

);
Insert into tblRailway values ('Shalimaar Express');
Insert into tblRailway values ('Allama Iqbal Express');
Insert into tblRailway values ('Taez Gaam Express');
Insert into tblRailway values ('Night Coach Express');
Insert into tblRailway values ('Blue Line Express')
Insert into tblRailway values ('Pak Business Express')

select * from tblRailway

---------------

Create table tblLogin
(
UID int identity (100,1) primary key,
UserName varchar (40) unique,
UPass varchar (20)



);
Insert into tblLogin values ('aryanshaikh008@gmail.com','123');

select * from tblLogin

-------------

Create table tblseats
(
seats varchar (20),

);
Insert into tblseats values ('1');
Insert into tblseats values ('2');
Insert into tblseats values ('3');
Insert into tblseats values ('4');
Insert into tblseats values ('5');





select * from tblseats